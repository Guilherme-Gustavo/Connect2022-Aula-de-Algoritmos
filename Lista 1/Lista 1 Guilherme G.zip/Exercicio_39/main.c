#include <stdio.h>
#include <stdlib.h>

int main()
{ //Exercicio sem leitura inicial de valores
    float salario_restante;
    salario_restante=1200-((200+120)*1.02);
    printf("O salario restante de Joao sera de %.2f reais", salario_restante);
}
