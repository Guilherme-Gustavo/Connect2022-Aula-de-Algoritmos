#include <stdio.h>
#include <stdlib.h>

int main()
{
    double n1, n2, n3;
    printf("Digite o primeiro numero: ");
    scanf("%lf", &n1);
    printf("Digite o segundo numero: ");
    scanf("%lf", &n2);
    printf("Digite o terceiro numero: ");
    scanf("%lf", &n3);
    printf("A multiplicacao dos tres numeros eh de %lf: ", n1*n2*n3);
}
