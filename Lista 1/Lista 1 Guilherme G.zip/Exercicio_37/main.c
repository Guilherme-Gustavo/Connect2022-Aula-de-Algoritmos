#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n;
    printf("Digite um numero para que seja exibida a sua tabuada: ");
    scanf("%d", &n);
    printf("\nA tabuada do numero eh  1X%2d=%2d", n, 1*n);
    printf("\nA tabuada do numero eh  2X%2d=%2d", n, 2*n);
    printf("\nA tabuada do numero eh  3X%2d=%2d", n, 3*n);
    printf("\nA tabuada do numero eh  4X%2d=%2d", n, 4*n);
    printf("\nA tabuada do numero eh  5X%2d=%2d", n, 5*n);
    printf("\nA tabuada do numero eh  6X%2d=%2d", n, 6*n);
    printf("\nA tabuada do numero eh  7X%2d=%2d", n, 7*n);
    printf("\nA tabuada do numero eh  8X%2d=%2d", n, 8*n);
    printf("\nA tabuada do numero eh  9X%2d=%2d", n, 9*n);
    printf("\nA tabuada do numero eh 10X%2d=%2d", n, 10*n);


}
