#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int maior_prino(int n);

int main()
{
    int n;
    setlocale(LC_ALL,"portuguese");
    printf("Digite um numero para verificar qual o maior numero primo menor que aquele n�mero: ");
    scanf("%d", &n);
    printf("O primo encontrado menor que o numero %d � %d.", n, maior_prino(n));
}


int maior_prino(int n){
    int primo_maior=0;
    for(int soma=0, i=2; i<=n;i++){
        for(int j=2; j<=i; j++){
            if(j%i==0){
            soma+=1;
            primo_maior=i;
        }

    }
    return primo_maior;
}
